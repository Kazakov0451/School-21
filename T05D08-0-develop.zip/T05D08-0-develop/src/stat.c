#include <stdio.h>
#define NMAX 10
#define TRUE 1
#define FALSE 0

int input(int *a, int *n);
void output(int *a, int *n);
int max(int *a, int *n, int max_v);
int min(int *a, int *n, int min_v);
double mean(int *a, int *n, double mean_v);
double variance(int *a, int *n, double variance_v, double mean_v);
void output_result1(double variance_v);

void output_result(int max_v,
                   int min_v,
                   double mean_v);

int main() {
  int n, data[NMAX];
  int max_v = -1000, min_v = 1000;
  double mean_v = 0.0, variance_v = 0.0, mean_v1;
  if (input(data, &n) == TRUE) {
    return TRUE;
  } else {
  output(data, &n);
  output_result(max(data, &n, max_v),
                min(data, &n, min_v),
                mean_v1 = mean(data, &n, mean_v));
  output_result1(variance(data, &n, variance_v, mean_v1));

    return TRUE;
}
}

int input(int *a, int *n) {
    char ent;
    int cout = 0;
    if (((scanf("%d%c", n, &ent) != 2) || (ent != '\n'))) {
        printf("n/a\n");
        return TRUE;
    } else {
        for (int *p = a; p - a < *n; p++) {
          cout++;
            if ((scanf("%d%c", p, &ent) != 2 || ent != '\n') &&
                ((ent != ' ') || cout == *n)) {
                printf("n/a\n");
                return TRUE;
            }
        }
    }
    return FALSE;
}
void output(int *a, int *n) {
    printf("%d", *a);
    for (int *p = a + 1; p - a < *n; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
int max(int *a, int *n, int max_v) {
    for (int *p = a; p - a < *n; p++) {
        if (*p > max_v) {
            max_v = *p;
        }
    }
  return max_v;
}
int min(int *a, int *n, int min_v) {
  for (int *p = a; p - a < *n; p++) {
        if (*p < min_v) {
            min_v = *p;
        }
  }
  return min_v;
}
double mean(int *a, int *n, double mean_v) {
  for (int *p = a; p - a < *n; p++) {
      mean_v += *p;
  }
  mean_v = mean_v / *n;
  return mean_v;
}
double variance(int *a, int *n, double variance_v, double mean_v1) {
  for (int *p = a; p - a < *n; p++) {
      variance_v += (*p - mean_v1) * (*p - mean_v1);
  }
  variance_v = variance_v / *n;
  return variance_v;
}
void output_result(int max_v,
                   int min_v,
                   double mean_v) {
    printf("%d %d %.6f ", max_v, min_v, mean_v);
}
void output_result1(double variance_v) {
  printf("%.6f\n", variance_v);
}
