#include <stdio.h>

 
int main() {
	double x, y;
	char ent;
	if((scanf("%lf%lf%c", &x,&y,&ent) != 3) || (ent != '\n')) 
	{
		printf("n/a \n");
	}
	else if ( (x * x + y * y) <= 25){
		printf("GOTCHA\n");
	}
	else{
		printf("MISS\n");
	}

}
