#include "cipher.h"

int main() {
    int x = 1, begin, key;
    char word[100], word1[100];
    while (x) {
        scanf("%d", &begin);
            if (begin == 1) {
                scanf("%s", word);
                if (read_file(word) == 1) {
                    char err = getc(stdin);
                    while (err != EOF && err != '\n') {
                    err = getc(stdin);
                    }
                    printf("n/a\n");
                }
            } else if (begin == 2) {
                if (write_file(word) == 1) {
                    char err = getc(stdin);
                    while (err != EOF && err != '\n') {
                    err = getc(stdin);
                    }
                    printf("n/a\n");
                }
                read_file(word);
            } else if (begin == 3) {
                scanf("%s", word1);
                scanf("%d", &key);
                open_dir_call_encrypt(word1, key);
            } else if (begin == -1) x = 0;
            else {
                char c = getc(stdin);
                while (c != EOF && c != '\n') {
                c = getc(stdin);
                }
                printf("n/a\n");
            }
    }
    return 0;
}

void open_dir_call_encrypt(char *word1, int key){
    char answer[100];
    DIR *directory;
    struct dirent *dir;
    directory = opendir(word1);
    for (int i = 0; i < 100; i++)
        answer[i] = word1[i];
    while ((dir = readdir(directory)) != NULL) {
        encrypt(word1, dir->d_name, key);
        for (int i = 0; i < 100; i++)
            word1[i] = answer[i];
    }
    closedir(directory);
}

void encrypt(char *word1, char *word, int key) {
    if ((strncmp((get_filename_ext(word)), "c", 1)) == 0) {
        encript(word, word1, key);
    } else if ((strncmp((get_filename_ext(word)), "h", 1)) == 0) {
        write_file_empty(word1, word);
    }
}

void write_file_empty(char *word, char *word1) {
    FILE *file;
    file = fopen(strcat(word, word1), "w");
    fclose(file);
}

const char *get_filename_ext(const char *word) {
    const char *dot = strrchr(word, '.');
    if(!dot || dot == word) return "";
    return dot + 1;
}

int write_file(char *word) {
    char answer[100], word1;
    word1 = getchar();
    FILE *file;
    file = fopen(word, "r");
    if (file == NULL) return 1;
    file = fopen(word, "a");
    for (int i = 0; (word1 = getchar()) != '\n'; i++) {
       answer[i] = word1;
       fprintf(file, "%c", word1);
    }
    fclose(file);
    return 0;
}

int read_file(char *word) {
    FILE *file;
    char answer;
    file = fopen(word, "r");
    if (file == NULL || exam(file) == 1) return 1;
    answer = fgetc(file);
    while (answer != EOF) {
        printf("%c", answer);
        answer = fgetc(file);
    }
    fclose(file);
    printf("\n");
    return 0;
}

void encript(char *word, char *word1, int key) {
    char err;
    int i = 0;
    FILE *file;
    file = fopen(strcat(word1, word), "r+");
    err = fgetc(file);
    while (err != EOF) {
        fseek(file, i, SEEK_SET);
        fprintf(file, "%c", caesar_cipher(err, key));
        err = fgetc(file);
        i++;
    }
}

char caesar_cipher(char character, int key) {
    if ( character <= 90 && character >= 65 ) {
        return (character - 65 + key) % 26 + 65;
    } else if ( character <= 122 && character >= 97 ) {
        return (character - 97 + key) % 26 + 97;
    } else {
        return character;
    }
}
int exam(FILE *file) {
    fseek(file, 0L, SEEK_END);
    int z = ftell(file);
    if (z == 0) return 1;
    rewind(file);
    return 0;
}
