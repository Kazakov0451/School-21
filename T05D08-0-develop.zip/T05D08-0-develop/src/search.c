#include <stdio.h>
#include <math.h>
#define NMAX 30
#define TRUE 1
#define FALSE 0

int input(int *a, int *n) {
    char ent;
    int cout = 0;
    if (((scanf("%d%c", n, &ent) != 2) || (ent != '\n'))) {
        printf("n/a\n");
        return TRUE;
    } else {
        for (int *p = a; p - a < *n; p++) {
          cout++;
            if ((scanf("%d%c", p, &ent) != 2 || ent != '\n') &&
                ((ent != ' ') || cout == *n)) {
                printf("n/a\n");
                return TRUE;
            }
        }
    }
    return FALSE;
}
double mean(int *a, int n) {
    double mean_v = 0.0;
  for (int *p = a; p - a < n; p++) {
      mean_v += *p;
  }
  mean_v = mean_v / n;
  return mean_v;
}
double variance(int *a, int n, double mean_v) {
    double variance_v = 0.0;
  for (int *p = a; p - a < n; p++) {
      variance_v += (*p - mean_v) * (*p - mean_v);
  }
  variance_v = variance_v / n;
  return variance_v;
}

int main() {
    int n, data[NMAX];
    int sear = 0;
    if (input(data, &n) == 1) {
        return TRUE;
    } else {
        double mean_v = mean(data, n);
        double variance_v = variance(data, n, mean_v);
    for (int *p = data; p - data < n; p++) {
        if (*p >= mean_v && *p != 0 && *p % 2 == 0 &&
            *p <= (mean_v + 3 * sqrt(variance_v))) {
            sear = *p;
            break;
        }
    }
    printf("%d\n", sear);
    }
}
