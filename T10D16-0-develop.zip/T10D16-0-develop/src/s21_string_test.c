#include <stdlib.h>
#include <stdio.h>
#include "s21_string.h"
void s21_strlen_test() {
    char *data1 = "Hello World!";
    char *data2 = "111";
    char *data3 = "ABCDEF#";
    int size_str;
    printf("%s\n", data1);
    size_str = s21_strlen(data1);
    printf("%d\n", size_str);
    if (size_str == 12) printf("SUCCESS\n");
    else
        printf("FAIL\n");
    printf("%s\n", data2);
    size_str = s21_strlen(data2);
    printf("%d\n", size_str);
    if (size_str == 3) printf("SUCCESS\n");
    else
        printf("FAIL\n");
    printf("%s\n", data3);
    size_str = s21_strlen(data3);
    printf("%d\n", size_str);
    if (size_str == 8) printf("SUCCESS\n");
    else
        printf("FAIL\n");
}
void s21_strcmp_test() {
    char *data1 = "Hello World!";
    char *data2 = "Hello World!";
    printf("%s\n", data1);
    printf("%s\n", data2);
    printf("%d\n", s21_strcmp(data1, data2));
    if (s21_strcmp(data1, data2) == 0) printf("SUCCESS\n");
    else
        printf("FAIL\n");
    char *data3 = "ABCDEF#";
    char *data4 = "abcdef#";
    printf("%s\n", data3);
    printf("%s\n", data4);
    printf("%d\n", s21_strcmp(data3, data4));
    if (s21_strcmp(data3, data4) == 0) printf("SUCCESS\n");
    else
        printf("FAIL\n");
    char *data5 = "12345";
    char *data6 = "13245";
    printf("%s\n", data5);
    printf("%s\n", data6);
    printf("%d\n", s21_strcmp(data5, data6));
    if (s21_strcmp(data5, data6) == 0) printf("SUCCESS\n");
    else
        printf("FAIL\n");
}
int main() {
    #ifdef QUEST1
    s21_strlen_test();
    #endif
    #ifdef QUEST2
    s21_strcmp_test();
    #endif
}
