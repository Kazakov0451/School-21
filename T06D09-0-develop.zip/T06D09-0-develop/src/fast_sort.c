#include <stdio.h>
#define TRUE 1
#define FALSE 0

int input(int *a) {
        for (int *p = a; p - a < 10; p++) {
            if (scanf("%d", p) != 1) {
                printf("n/a\n");
                return TRUE;
            }
        }
    return FALSE;
}

void output(int *arr) {
    printf("%d", *arr);
    for (int *p = arr + 1; p - arr < 10; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
void sortbuble(int *arr, int x) {
    for (int *p = arr; p - arr < 10; p++) {
        for (int *p1 = arr + 9; p1 > p; p1--) {
            if (*(p1 - 1) > *p1) {
                x = *(p1 - 1);
                *(p1 - 1) = *p1;
                *p1 = x;
            }
        }
    }
}
void qsort(int *arr) {
    int i = 0, j = 10 - 1;
    int mid = arr[10 / 2];
    do {
        while (arr[i] < mid) {
            i++;
        }
        while (arr[j] > mid) {
            j--;
        }
        if (i <= j) {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    } while (i <= j);
}

int main() {;
    int arr[10], x = 0;
    if (input(arr) == 1) {
        return TRUE;
    } else {
        sortbuble(arr, x);
        output(arr);
        qsort(arr);
        output(arr);
}
}
