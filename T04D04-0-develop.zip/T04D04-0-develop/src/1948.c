#include <stdio.h>
#include<math.h>

int exam(int i){
	int c, ans = 0, j = 2;
	ans = i;
	while(j < i){      
		while(i > c) {  
			i = i - j;
			c = c + j;
			}
			if (i == 0){
				i = c;
				c = 0;
				break;
			}
		j++;
	}
	return ans;
}


int div_int(int a){
	int b = 0, cout = 0, ans, i = 2, x;
	x = a;
	while(i <= x){
		while(a > 0){
			a = a - i;
			b = b + i;
		}
		b = 0;
		ans = exam(i);
		cout = ans;
		i++;
	}
	return cout; 
}


int main(){
	int a;
	char ent;
	if((scanf("%d%c", &a,&ent) != 2) || (ent != '\n'))
	{
		printf("n/a\n");
	}
	else{
		a = div_int(a);
		printf("%d\n", a);
	}
}

