#include <stdio.h>
#define TRUE 1
#define FALSE 0

int input(int *a) {
        for (int *p = a; p - a < 10; p++) {
            if (scanf("%d", p) != 1) {
                printf("n/a\n");
                return TRUE;
            }
        }
    return FALSE;
}

void output(int *a) {
    printf("%d", *a);
    for (int *p = a + 1; p - a < 10; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
int sort(int *a, int x) {
    for (int *p = a; p - a < 10; p++) {
        for (int *p1 = a + 9; p1 > p; p1--) {
            if (*(p1 - 1) > *p1) {
                x = *(p1 - 1);
                *(p1 - 1) = *p1;
                *p1 = x;
            }
        }
    }
    return TRUE;
}
int main() {
    int data[10], x = 0;
    if (input(data) == 1) {
        return TRUE;
    } else {
        sort(data, x);
        output(data);
    }
}
