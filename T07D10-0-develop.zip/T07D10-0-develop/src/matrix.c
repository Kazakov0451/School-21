#include <stdio.h>
#include <stdlib.h>
#define MAX 10
// int input_choose_matrix(int *n) {
//     int flag = 0;
//     if (scanf("%d", n) != 1 || n >= 5){
//         flag = 1;
//     }
//     return 0;
// }
int input_size_matrix(int i, int j) {
    scanf("%d%d", &i, &j);
    return 0;
}
int matrix_dynamic1(int *arr, int i, int j){
    int cout;
    int *arr = (int) malloc(i * sizeof(int*));
    for (int i1 = 0; i1 < i; i1++)
        arr[i1] =(int) malloc(j * sizeof(int*));
    for (int i1 = 0; i1 < i; i1++)
        for(int j1 = 0; j1 < j; j1++)
            scanf("%d", &arr[i1][j1]);
    for (int i1 = 0; i1 < i; i1++)
        for(int j1 = 0; j1 < j; j1++)
            printf("%d ",  arr[i1][j1]);
    for (int i1 = 0; i1 < i; i1++)
        free(arr[i1]);
    free(arr);
}
// int matrix_stat(int **arr1, int *i, int *j){
//     for(int i1 = 0; i1 < *i; i1++){
//     for(int j1 = 0; j1 < *j; j1++){
//     	    scanf("%d", &arr1[i1][j1]);
//     	}
//     }
//     return 0;
// }
// void output(int **arr1, int i, int j) {
//     printf("%d", arr1[i][j]);
//     for(int i1 = 0; i1 < i; i1++){
//     for(int j1 = 0; j1 < j; j1++){
//         	printf(" %d", &arr1[i1][j1]);
//     }
//     }
//     printf("\n");
// }
int main(){
    int **arr = NULL;
    int i = 0, j = 0;
    input_size_matrix(i, j);
    matrix_dynamic1(arr, i, j);

    // int arr1[i][j];
    // int *p = arr1;
    //input_chose_matrix(&n);
    // matrix_stat(p, &i, &j);
    //output(arr1, i, j);
}
