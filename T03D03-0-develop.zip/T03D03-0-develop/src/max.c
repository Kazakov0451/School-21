#include <stdio.h>

int max_value(int a, int b);

int main(){
	int a, b;
	char ent;
	if((scanf("%d%d%c", &a,&b,&ent) != 3) || (ent != '\n'))
	{
		printf("n/a\n");
	} 
	else
	{
			printf("%d\n",max_value(a,b));
	}

}

int max_value(int a, int b){
	int max = -10000;
	if ( a > b){
		return max = a;
	}
	else if(b > a){
		return max = b;

	}
	else  {
		return max = a;
	}
}