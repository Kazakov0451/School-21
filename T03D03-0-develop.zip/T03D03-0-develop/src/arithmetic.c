#include <stdio.h>

int sum(int a, int b);
int div(int a, int b);
int subtraction(int a, int b);
int multiplication(int a, int b);
int error(int b);


int main()
{
	char ent;
	int s, sub, mul, d, a, b;
	if((scanf("%d%d%c",&a,&b,&ent) != 3) || (ent != '\n')){
		printf("n/a\n");
	}
	else{
	if (error(b) == 0){
	s = sum(a, b);
    sub = subtraction(a, b);
    mul = multiplication(a, b);
    printf("Отевт:%d %d %d n/a\n", s, sub, mul);
	}
	else{
    s = sum(a, b);
    sub = subtraction(a, b);
    mul = multiplication(a, b);
    d = div(a, b);
    printf("Отевт:%d %d %d %d\n", s, sub, mul, d);
}}
}

int sum(int a, int b)
{
	int k = a + b;
    return k;
}

int div(int a, int b)
{
	int k = a/b;
	return k;
}

int error(int b)
{
	if (b == 0){
		return 0;
	}
	else return 1;
}


int subtraction(int a, int b)
{
	int k = a - b;
    return k;
}

int multiplication(int a, int b)
{
	int k = a * b;
    return k;
}