cd /Users/littleak/desktop/git/develop/src/ai_help/
chmod +x keygen.sh
bash keygen.sh
cd key
rm file*
cd /Users/littleak/desktop/git/develop/src/ai_help
chmod +x unifier.sh
bash unifier.sh
ls /Users/littleak/desktop/git/develop/src/ai_help

