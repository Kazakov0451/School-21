#include <stdio.h>

int main()
{
	int name = 0;

	printf("Enter name:");
	scanf("%d", &name);
	printf("Hello, %d! \n", name);
}

