#include <stdio.h>
#define NMAX 10
#define TRUE 1
#define FALSE 0

int input(int *a, int *n);
void output(int *a, int *n);
void squaring(int *a, int *n);

int main() {
    int n, data[NMAX];
    if (input(data, &n) == TRUE) {
        return TRUE;
    } else {
    squaring(data, &n);
    output(data, &n);
    return TRUE;
}
}
int input(int *a, int *n) {
    char ent;
    if (((scanf("%d%c", n, &ent) != 2) || (ent != '\n'))) {
        printf("n/a\n");
        return TRUE;
    } else {
        for (int *p = a; p - a < *n; p++) {
            if ((scanf("%d%c", p, &ent) != 2 || ent != '\n') &&
                ((ent != ' ') || (*p == *n))) {
                printf("n/a\n");
                return TRUE;
            }
        }
    }
    return FALSE;
}
void output(int *a, int *n) {
        printf("%d", *a);
        for (int *p = a + 1; p - a < *n; p++) {
            printf(" %d", *p);
        }
        printf("\n");
}
void squaring(int *a, int *n) {
    for (int *p = a; p - a < *n; p++) {
        *p = *p * *p;
    }
}
