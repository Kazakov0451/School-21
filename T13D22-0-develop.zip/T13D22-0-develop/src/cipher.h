#ifndef CIPHER_H_
#define CIPHER_H_
#include <dirent.h>
#include <string.h>
#include <stdio.h>

void open_dir_call_encrypt(char *word2, int key);
void encrypt(char *word2, char *word, int key);
void write_file_empty(char *filepath, char *word);
const char *get_filename_ext(const char *word);
int check_if_empty(char *word);
int write_file(char *word);
int read_file(char *word);
void encript(char *word, char *filepath, int key);
char caesar_cipher(char character, int key);
int exam(FILE *file);

#endif