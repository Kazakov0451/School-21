#include "s21_string.h"
int s21_strlen(char *str) {
    int length = 0;
    for (; str[length] != '\0'; length++)
    {}
        return length;
}
int s21_strcmp(char *str1, char *str2) {
    for (; *str1 && *str1 == *str2; str1++, str2++)
    {}
        return *str1-*str2;
}
