#include <stdio.h>
#include <stdlib.h>

int input_n(int *n) {
    int flag = 0;
    if (scanf("%d", n) != 1){
        flag = 1;
    }
    return flag;
}
int input_p(int *a, int *n) {
    int flag = 0;
    for (int *p = a; p - a < *n; p++) {
        if (scanf("%d", p) != 1) {
            flag = 1;
        }
    }
        return flag;
}
void output(int *a, int *n) {
    printf("%d", *a);
    for (int *p = a + 1; p - a < *n; p++) {
        printf(" %d", *p);
    }
    printf("\n");
}
int* sort(int *a, int *n) {
    for (int *p = a; p - a < *n; p++) {
        for (int *p1 = a + (*n - 1); p1 > p; p1--) {
            if (*(p1 - 1) > *p1) {
                int x = *(p1 - 1);
                *(p1 - 1) = *p1;
                *p1 = x;
            }
        }
    }
    return a;
}
int main() {
    int *p = NULL, n;
    if (input_n(&n) == 1){
        printf("n/a");
        free(p);
    } else {
        p = (int*) malloc(n * sizeof(int));
        if (input_p(p, &n) == 1){
            printf("n/a");
            free(p);
        } else {
            sort(p, &n); 
            output(p, &n);
            free(p);
        }
    }
}